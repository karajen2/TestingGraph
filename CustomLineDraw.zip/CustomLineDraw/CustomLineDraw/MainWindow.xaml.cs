﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawNewLines();

            //touch up

            Line tc_1 = new Line();
            tc_1.Stroke = Brushes.Black;
            tc_1.X1 = 100;
            tc_1.Y1 = 0;
            tc_1.X2 = 100;
            tc_1.Y2 = -20;

            MainGrid.Children.Add(tc_1);

            Line tc_2 = new Line();
            tc_2.Stroke = Brushes.Black;
            tc_2.X1 = 400;
            tc_2.Y1 = 0;
            tc_2.X2 = 400;
            tc_2.Y2 = -20;

            MainGrid.Children.Add(tc_2);

            Line tc_3 = new Line();
            tc_3.Stroke = Brushes.Black;
            tc_3.X1 = 100;
            tc_3.Y1 = 420;
            tc_3.X2 = 100;
            tc_3.Y2 = 430;

            MainGrid.Children.Add(tc_3);

            Line tc_4 = new Line();
            tc_4.Stroke = Brushes.Black;
            tc_4.X1 = 400;
            tc_4.Y1 = 420;
            tc_4.X2 = 400;
            tc_4.Y2 = 430;

            MainGrid.Children.Add(tc_4);

            viewBx.Height =500;
            viewBx.Width = 500;
        }
        Line firstLine = new Line();
        Line secondLine = new Line();
        Line thirdLine = new Line();
        Line fourthLine = new Line();
        Line fifthLine = new Line();
        TextBlock tb1;
        TextBlock tb2;
        TextBlock tb3;
        TextBlock tb4;
        TextBlock tb5;

        private void DrawNewLines()
        {
            //Line maxMark = new Line();
            //maxMark.Stroke = Brushes.Black;
            //maxMark.StrokeThickness = 1;
            //maxMark.X1 = 100;
            //maxMark.Y1 = 0;
            //maxMark.X2 = 107;
            //maxMark.Y2 = 0;
            //TextBlock tbm1 = new TextBlock();
            //tbm1.Text = ReturnYAxis(Convert.ToInt32(maxMark.Y1)).ToString();
            //tbm1.Margin = new Thickness(70, 0, 0, 0);
            //MainGrid.Children.Add(tbm1);
            //MainGrid.Children.Add(maxMark);

            //Line minMark = new Line();
            //minMark.Stroke = Brushes.Black;
            //minMark.StrokeThickness = 1;
            //minMark.X1 = 100;
            //minMark.Y1 = 420;
            //minMark.X2 = 100;
            //minMark.Y2 = 420;
            //TextBlock tbm2 = new TextBlock();
            //tbm2.Text = ReturnYAxis(Convert.ToInt32(minMark.Y1)).ToString();
            //tbm2.Margin = new Thickness(70, 420, 0, 0);
            //MainGrid.Children.Add(tbm2);
            //MainGrid.Children.Add(minMark);
            
            List<int> rightSide = new List<int> { Convert.ToInt32(b.Text), Convert.ToInt32(d.Text), Convert.ToInt32(f.Text), Convert.ToInt32(g.Text),Convert.ToInt32(h.Text) };
            List<int> leftSide = new List<int> { Convert.ToInt32(a.Text), Convert.ToInt32(c.Text), Convert.ToInt32(f.Text), Convert.ToInt32(g.Text), Convert.ToInt32(h.Text) };

            int maxi = rightSide.Max();
            int s = 260 - maxi;

            int mini = leftSide.Min();
            int k = 160 + mini;

            firstLine.Stroke = Brushes.Green;
            firstLine.StrokeThickness = 1;
            firstLine.X1 = 100;
            firstLine.Y1 = ReturnYAxis(Convert.ToInt32(a.Text) - k) ;
            firstLine.X2 = 400;
            firstLine.Y2 = ReturnYAxis(Convert.ToInt32(b.Text) + s);
            firstLine.ToolTip = "(" + a.Text + ", " + b.Text + ")";
            tb1 = new TextBlock();
            tb1.Text = Convert.ToInt32(a.Text).ToString();
            tb1.Margin = new Thickness(100, firstLine.Y1, 0, 0);
            MainGrid.Children.Add(tb1);
            MainGrid.Children.Add(firstLine);


            secondLine.Stroke = Brushes.Gold;
            secondLine.StrokeThickness = 1;
            secondLine.X1 = 99;
            secondLine.Y1 = ReturnYAxis(Convert.ToInt32(c.Text) + 10  -k);
            secondLine.X2 = 400;
            secondLine.Y2 = ReturnYAxis(Convert.ToInt32(d.Text) + 10 + s);
            secondLine.ToolTip = "(" + c.Text + ", " + d.Text + ")";
            tb2 = new TextBlock();
            tb2.Text = Convert.ToInt32(c.Text).ToString();
            tb2.Margin = new Thickness(100, secondLine.Y1, 0, 0);
            secondLine.ToolTip = "(" + c.Text + ", " + d.Text + ")";
            MainGrid.Children.Add(tb2);
            MainGrid.Children.Add(secondLine);



            thirdLine.Stroke = Brushes.Orange;
            thirdLine.StrokeDashArray = new DoubleCollection { 4 };
            thirdLine.StrokeThickness = 1;
            thirdLine.X1 = 100;
            thirdLine.Y1 = ReturnYAxis(Convert.ToInt32(f.Text) - k);
            thirdLine.X2 = 400;
            thirdLine.Y2 = ReturnYAxis(Convert.ToInt32(f.Text) - k);
            thirdLine.ToolTip = "(" + f.Text + ", " + f.Text + ")";
            tb3 = new TextBlock();
            tb3.Text = Convert.ToInt32(f.Text).ToString();
            tb3.Margin = new Thickness(100, thirdLine.Y1, 0, 0);
            MainGrid.Children.Add(tb3);
            MainGrid.Children.Add(thirdLine);


            fourthLine.Stroke = Brushes.DarkOliveGreen;
            fourthLine.StrokeDashArray = new DoubleCollection { 6 };
            fourthLine.StrokeThickness = 1;
            fourthLine.X1 = 100;
            fourthLine.Y1 = ReturnYAxis(Convert.ToInt32(g.Text) - k);
            fourthLine.X2 = 400;
            fourthLine.Y2 = ReturnYAxis(Convert.ToInt32(g.Text) - k);
            fourthLine.ToolTip = "(" + g.Text + ", " + g.Text + ")";
            tb4 = new TextBlock();
            tb4.Text = Convert.ToInt32(g.Text).ToString();
            tb4.Margin = new Thickness(100, fourthLine.Y1, 0, 0);
            MainGrid.Children.Add(tb4);
            MainGrid.Children.Add(fourthLine);

            Line fifthLine = new Line();
            fifthLine.Stroke = Brushes.Yellow;
            fifthLine.StrokeThickness = 1;
            fifthLine.X1 = 99;
            fifthLine.Y1 = ReturnYAxis(Convert.ToInt32(h.Text) - k);
            fifthLine.X2 = 400;
            fifthLine.Y2 = ReturnYAxis(Convert.ToInt32(h.Text) - k);
            fifthLine.ToolTip = "(" + h.Text + ", " + h.Text + ")";
            tb5 = new TextBlock();
            tb5.Text = Convert.ToInt32(h.Text).ToString();
            tb5.Margin = new Thickness(100, fifthLine.Y1, 0, 0);
            MainGrid.Children.Add(tb5);
            MainGrid.Children.Add(fifthLine);


            //Line zeroMark = new Line();
            //zeroMark.Stroke = Brushes.Black;
            //zeroMark.StrokeThickness = 1;
            //zeroMark.X1 = 100;
            //zeroMark.Y1 = 260;
            //zeroMark.X2 = 107;
            //zeroMark.Y2 = 260;
            //MainGrid.Children.Add(zeroMark);
            //TextBlock tbm3 = new TextBlock();
            //tbm3.Text = ReturnYAxis(Convert.ToInt32(zeroMark.Y1)).ToString();
            //tbm3.Margin = new Thickness(70, 260, 0, 0);
            //MainGrid.Children.Add(tbm3);

            //secondLine.Stroke = Brushes.Purple;
            //secondLine.StrokeThickness = 1;
            //secondLine.X1 = 99;
            //secondLine.Y1 = ReturnYAxis(Convert.ToInt32(c.Text) + 10);
            //secondLine.X2 = 400;
            //secondLine.Y2 = ReturnYAxis(Convert.ToInt32(d.Text) + 10);
            //tb2 = new TextBlock();
            //tb2.Text = Convert.ToInt32(c.Text).ToString();
            //tb2.Margin = new Thickness(100, secondLine.Y1, 0, 0);
            //secondLine.ToolTip = "(" + c.Text + ", " + d.Text + ")";
            //MainGrid.Children.Add(tb2);
            //MainGrid.Children.Add(secondLine);
            
        }

        public int ReturnYAxis(int y)
        {
            if(y < 0)
            {
                return 260 + Math.Abs(y);
            }
            if( y >= 0)
            {
                return 260 - y;
            }
         
            return 0;
        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 430, X2 = 400, Y2 = 430 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 0, X2 = 100, Y2 = 420 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 400, Y1 = 0, X2 = 400, Y2 = 420 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);
        }

       
        private void Draw(object sender, RoutedEventArgs e)
        {
            if (firstLine != null && secondLine != null && thirdLine != null && fourthLine != null && fifthLine != null)
            {
                MainGrid.Children.Remove(firstLine);
                MainGrid.Children.Remove(secondLine);
                MainGrid.Children.Remove(thirdLine);
                MainGrid.Children.Remove(fourthLine);
                MainGrid.Children.Remove(fifthLine);

                MainGrid.Children.Remove(tb1);
                MainGrid.Children.Remove(tb2);
                MainGrid.Children.Remove(tb3);
                MainGrid.Children.Remove(tb4);
                MainGrid.Children.Remove(tb5);
            }
            DrawNewLines();

        }


    }
}
    
