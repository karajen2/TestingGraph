﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawDots ();
        }

        private void DrawDots () {
            Line e1;
            Line e2;
            TextBlock tb1;
            TextBlock tb2;

            for (int i = 0, j = 100; i < 200; i += 20, j -= 20) {
                e1 = new Line ();
                e1.StrokeThickness = 10;
                e1.Stroke = Brushes.Red;
                e1.X1 = 100;
                e1.X2 = 100;
                e1.Y1 = i;
                e1.Y2 = i + 1;
                tb1 = new TextBlock ();
                tb1.Text = j.ToString ();
                tb1.Margin = new Thickness (100 + 5, e1.Y1 - 5, 0, -2);

                //e2 = new Line ();
                //e2.StrokeThickness = 10;
                //e2.Stroke = Brushes.Red;
                //e2.X1 = 300;
                //e2.X2 = 300;
                //e2.Y1 = i;
                //e2.Y2 = i + 1;
                //tb2 = new TextBlock ();
                //tb2.Text = j.ToString ();
                //tb2.Margin = new Thickness (300 + 5, e2.Y1 - 5, 0, 0);

                MainGrid.Children.Add (tb1);
                //MainGrid.Children.Add (tb2);

                MainGrid.Children.Add (e1);
                //MainGrid.Children.Add (e2);
            }
        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 200, X2 = 300, Y2 = 200 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 0, X2 = 100, Y2 = 200 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 300, Y1 = 0, X2 = 300, Y2 = 200 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);

            //extentions - not funtionally useful
            Line lx = new Line { X1 = 100, Y1 = 0, X2 = 100, Y2 = -20 };
            lx.Stroke = Brushes.Black;
            MainGrid.Children.Add (lx);

            Line ly = new Line { X1 = 300, Y1 = 0, X2 = 300, Y2 = -20 };
            ly.Stroke = Brushes.Black;
            MainGrid.Children.Add (ly);
        }

        private Line l;
        private Line l1;

        private void Draw (object sender, RoutedEventArgs e) {
            if (l != null && l1 != null) {
                MainGrid.Children.Remove (l);
                MainGrid.Children.Remove (l1);
            }

            l = new Line ();
            l1 = new Line ();

            l.X1 = 100;
            l.Y1 = 100 - Convert.ToDouble (a.Text);
            l.X2 = 300;
            l.Y2 = 100 - Convert.ToDouble (b.Text);
            l.Stroke = Brushes.Blue;
            l.StrokeThickness = 0.5;
            MainGrid.Children.Add (l);

            l1.X1 = 100;
            l1.Y1 = 100 - Convert.ToDouble (c.Text);
            l1.X2 = 300;
            l1.Y2 = 100 - Convert.ToDouble (d.Text);
            l1.Stroke = Brushes.Red;
            l.StrokeThickness = 0.5;
            MainGrid.Children.Add (l1);
        }
    }
}