﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawDots ();
        }

        private void DrawDots () {
            Line e1;
            Line e2;
            TextBlock tb1;
            TextBlock tb2;

            for (int i = 0, j = 100; i < 200; i += 20, j -= 20) {
                e1 = new Line ();
                e1.StrokeThickness = 10;
                e1.Stroke = Brushes.Black;
                e1.X1 = 100;
                e1.X2 = 100;
                e1.Y1 = i;
                e1.Y2 = i + 1;
                tb1 = new TextBlock ();
                tb1.Text = j.ToString ();
                tb1.Margin = new Thickness (100 + 5, e1.Y1 - 5, 0, -2);

                //e2 = new Line();
                //e2.StrokeThickness = 10;
                //e2.Stroke = Brushes.Red;
                //e2.X1 = 300;
                //e2.X2 = 300;
                //e2.Y1 = i;
                //e2.Y2 = i + 1;
                //tb2 = new TextBlock();
                //tb2.Text = j.ToString();
                //tb2.Margin = new Thickness(300 + 5, e2.Y1 - 5, 0, 0);

                MainGrid.Children.Add (tb1);
               // MainGrid.Children.Add(tb2);

                MainGrid.Children.Add(e1);
                //MainGrid.Children.Add(e2);
            }
        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 200, X2 = 300, Y2 = 200 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 0, X2 = 100, Y2 = 200 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 300, Y1 = 0, X2 = 300, Y2 = 200 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);

            ////extentions - not funtionally useful
            //Line lx = new Line { X1 = 100, Y1 = 0, X2 = 100, Y2 = -20 };
            //lx.Stroke = Brushes.Black;
            //MainGrid.Children.Add (lx);

            //Line ly = new Line { X1 = 300, Y1 = 0, X2 = 300, Y2 = -20 };
            //ly.Stroke = Brushes.Black;
            //MainGrid.Children.Add (ly);
        }

        private Line l;
        private Line l1;
        private Line l2;
        private Line l3;
        private Line l4;

        private void Draw(object sender, RoutedEventArgs e)
        {
            if (l != null && l1 != null && l2!=null && l3!=null && l4!=null)
            {
                MainGrid.Children.Remove(l);
                MainGrid.Children.Remove(l1);
                MainGrid.Children.Remove(l2);
                MainGrid.Children.Remove(l3);
                MainGrid.Children.Remove(l4);
            }

            l = new Line();
            l1 = new Line();
            l2 = new Line();
            l3 = new Line();
            l4 = new Line();
            if(c.Text.Equals("")&& d.Text.Equals(""))
            {
                l.X1 = 100;
                l.Y2 = 100 - Convert.ToDouble(a.Text);
                l.X2 = 300;
                l.Y1 = 100 - Convert.ToDouble(b.Text);
                l.Stroke = Brushes.Blue;
                l.StrokeThickness = 1.5;
                l.ToolTip = "(" + b.Text + ", " + a.Text + ")";
                MainGrid.Children.Add(l);

                

            }
            else
            {
                l.X1 = 100;
                l.Y2= 100 - Convert.ToDouble(a.Text);
                l.X2 = 300;
                l.Y1 = 100 - Convert.ToDouble(b.Text);
                l.Stroke = Brushes.Blue;
                l.StrokeThickness = 1.5;
                l.ToolTip = "(" + b.Text + ", " + a.Text + "+)";
                MainGrid.Children.Add(l);

                l1.X1 = 100;
                l1.Y2 = 100 - (Convert.ToDouble(c.Text) + Convert.ToDouble(a.Text)); 
                l1.X2 = 300;
                l1.Y1 = 100 - (Convert.ToDouble(d.Text) + Convert.ToDouble(b.Text)); 
                l1.Stroke = Brushes.Red;
                l1.StrokeThickness = 1.5;
                l1.ToolTip = "(" + d.Text + ", " + c.Text + ")";
                MainGrid.Children.Add(l1);
            }

            l2.X1 = 100;
            l2.Y1 = 100 - Convert.ToDouble(f.Text);
            l2.X2 = 300;
            l2.Y2 = l2.Y1;
            l2.Stroke = Brushes.Red;
            l2.StrokeDashArray = new DoubleCollection() { 5 };
            l1.ToolTip = "(" + f.Text + ", " + f.Text + ")";
            MainGrid.Children.Add(l2);


            l3.X1 = 100;
            l3.Y1 = 100 - Convert.ToDouble(g.Text);
            l3.X2 = 300;
            l3.Y2 = l3.Y1;
            l3.Stroke = Brushes.Blue;
            l3.StrokeDashArray = new DoubleCollection() { 5 };
            l3.ToolTip = "(" + g.Text + ", " + g.Text + ")";
            MainGrid.Children.Add(l3);

            l4.X1 = 100;
            l4.Y1 = 100 - Convert.ToDouble(h.Text);
            l4.X2 = 300;
            l4.Y2 = l4.Y1;
            l4.Stroke = Brushes.Yellow;
            l4.StrokeThickness = 1.5;
            l4.ToolTip = "(" + h.Text + ", " + h.Text + ")";
            MainGrid.Children.Add(l4);

        }
    }
}
    
