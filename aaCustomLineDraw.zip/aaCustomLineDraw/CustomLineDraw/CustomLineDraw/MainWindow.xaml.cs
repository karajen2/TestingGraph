﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawNewLines();
        }
        Line firstLine = new Line();
        Line secondLine = new Line();
        Line thirdLine = new Line();
        Line fourthLine = new Line();
        Line fifthLine = new Line();
        TextBlock tb1;
        TextBlock tb2;
        TextBlock tb3;
        TextBlock tb4;
        TextBlock tb5;

        private void DrawNewLines()
        {
            firstLine.Stroke = Brushes.Green;
            firstLine.StrokeThickness = 1;
            firstLine.X1 = 99;
            firstLine.Y1 = ReturnYAxis( Convert.ToInt32(a.Text));
            firstLine.X2 = 300;
            firstLine.Y2 = ReturnYAxis(Convert.ToInt32(b.Text));
            firstLine.ToolTip = "(" + a.Text + ", " + b.Text + ")";
            tb1 = new TextBlock();
            tb1.Text = Convert.ToInt32(a.Text).ToString();
            tb1.Margin = new Thickness(100, firstLine.Y1, 0, 0);
            MainGrid.Children.Add(tb1);
            MainGrid.Children.Add(firstLine);
            
            secondLine.Stroke = Brushes.Purple;
            secondLine.StrokeThickness = 1;
            secondLine.X1 = 99;
            secondLine.Y1 = ReturnYAxis(Convert.ToInt32(c.Text) + 10);
            secondLine.X2 = 300;
            secondLine.Y2 = ReturnYAxis(Convert.ToInt32(d.Text) + 10);
            MainGrid.Children.Add(secondLine);
            tb2 = new TextBlock();
            tb2.Text = Convert.ToInt32(c.Text).ToString();
            tb2.Margin = new Thickness(100, secondLine.Y1, 0, 0);
            MainGrid.Children.Add(tb2);
            secondLine.ToolTip = "(" + c.Text + ", " + d.Text + ")";
           
            thirdLine.Stroke = Brushes.Orange;
            thirdLine.StrokeDashArray = new DoubleCollection { 4 };
            thirdLine.StrokeThickness = 1;
            thirdLine.X1 = 99;
            thirdLine.Y1 = ReturnYAxis(Convert.ToInt32(f.Text) );
            thirdLine.X2 = 300;
            thirdLine.Y2 = ReturnYAxis(Convert.ToInt32(f.Text) );
            MainGrid.Children.Add(thirdLine);
            tb3 = new TextBlock();
            tb3.Text = Convert.ToInt32(f.Text).ToString();
            tb3.Margin = new Thickness(100, thirdLine.Y1, 0, 0);
            MainGrid.Children.Add(tb3);
            thirdLine.ToolTip = "(" + f.Text + ", " + f.Text + ")";

            
            fourthLine.Stroke = Brushes.Brown;
            fourthLine.StrokeDashArray = new DoubleCollection { 6 };
            fourthLine.StrokeThickness = 1;
            fourthLine.X1 = 99;
            fourthLine.Y1 = ReturnYAxis(Convert.ToInt32(g.Text));
            fourthLine.X2 = 300;
            fourthLine.Y2 = ReturnYAxis(Convert.ToInt32(g.Text));
            MainGrid.Children.Add(fourthLine);
             tb4 = new TextBlock();
            tb4.Text = Convert.ToInt32(g.Text).ToString();
            tb4.Margin = new Thickness(100, fourthLine.Y1, 0, 0);
            MainGrid.Children.Add(tb4);
            fourthLine.ToolTip = "(" + g.Text + ", " + g.Text + ")";

            Line fifthLine = new Line();
            fifthLine.Stroke = Brushes.Yellow;
            fifthLine.StrokeThickness = 1;
            fifthLine.X1 = 99;
            fifthLine.Y1 = ReturnYAxis(Convert.ToInt32(h.Text));
            fifthLine.X2 = 300;
            fifthLine.Y2 = ReturnYAxis(Convert.ToInt32(h.Text));
            MainGrid.Children.Add(fifthLine);
            tb5 = new TextBlock();
            tb5.Text = Convert.ToInt32(h.Text).ToString();
            tb5.Margin = new Thickness(100, fifthLine.Y1, 0, 0);
            MainGrid.Children.Add(tb5);
            fifthLine.ToolTip = "(" + h.Text + ", " + h.Text + ")";


            Line maxMark = new Line();
            maxMark.Stroke = Brushes.Black;
            maxMark.StrokeThickness = 1;
            maxMark.X1 = 99;
            maxMark.Y1 = 0;
            maxMark.X2 = 107;
            maxMark.Y2 = 0;
            TextBlock tbm1 = new TextBlock();
            tbm1.Text = ReturnYAxis(Convert.ToInt32(maxMark.Y1)).ToString();
            tbm1.Margin = new Thickness(70, 0, 0, 0);
            MainGrid.Children.Add(tbm1);
            MainGrid.Children.Add(maxMark);

            Line maxMark_1 = new Line();
            maxMark_1.Stroke = Brushes.Black;
            maxMark_1.StrokeThickness = 1;
            maxMark_1.X1 = 99;
            maxMark_1.Y1 = 100;
            maxMark_1.X2 = 107;
            maxMark_1.Y2 = 100;
            TextBlock tbm2 = new TextBlock();
            tbm2.Text = ReturnYAxis(Convert.ToInt32(maxMark_1.Y1)).ToString();
            tbm2.Margin = new Thickness(70, 100, 0, 0);
            MainGrid.Children.Add(tbm2);
            MainGrid.Children.Add(maxMark_1);

            Line maxMark_2 = new Line();
            maxMark_2.Stroke = Brushes.Black;
            maxMark_2.StrokeThickness = 1;
            maxMark_2.X1 = 99;
            maxMark_2.Y1 = 200;
            maxMark_2.X2 = 107;
            maxMark_2.Y2 = 200;
            TextBlock tbm3 = new TextBlock();
            tbm3.Text = ReturnYAxis(Convert.ToInt32(maxMark_2.Y1)).ToString();
            tbm3.Margin = new Thickness(70, 200, 0, 0);
            MainGrid.Children.Add(tbm3);
            MainGrid.Children.Add(maxMark_2);

            //touch up

            Line tc_1 = new Line();
            tc_1.Stroke = Brushes.Black;
            tc_1.X1 = 100;
            tc_1.Y1 = 0;
            tc_1.X2 = 100;
            tc_1.Y2 = -20;

            MainGrid.Children.Add(tc_1);

            Line tc_2 = new Line();
            tc_2.Stroke = Brushes.Black;
            tc_2.X1 = 300;
            tc_2.Y1 = 0;
            tc_2.X2 = 300;
            tc_2.Y2 = -20;

            MainGrid.Children.Add(tc_2);

        }

        public int ReturnYAxis(int y)
        {
            int referenceMin = -160;
            int nutral = 260;
            int ourScale = 300;

            if (y < 0)
            {
                int fact = referenceMin - y;
                return ourScale - Math.Abs(fact);
            }
            else if (y >= 0)
            {
                int nfact = nutral - y;
                return nfact;
            }

            return 0;
        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 300, X2 = 300, Y2 = 300 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 0, X2 = 100, Y2 = 300 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 300, Y1 = 0, X2 = 300, Y2 = 300 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);
        }

       
        private void Draw(object sender, RoutedEventArgs e)
        {
            if (firstLine != null && secondLine != null && thirdLine != null && fourthLine != null && fifthLine != null)
            {
                MainGrid.Children.Remove(firstLine);
                MainGrid.Children.Remove(secondLine);
                MainGrid.Children.Remove(thirdLine);
                MainGrid.Children.Remove(fourthLine);
                MainGrid.Children.Remove(fifthLine);

                MainGrid.Children.Remove(tb1);
                MainGrid.Children.Remove(tb2);
                MainGrid.Children.Remove(tb3);
                MainGrid.Children.Remove(tb4);
                MainGrid.Children.Remove(tb5);
            }
            DrawNewLines();

        }


    }
}
    
