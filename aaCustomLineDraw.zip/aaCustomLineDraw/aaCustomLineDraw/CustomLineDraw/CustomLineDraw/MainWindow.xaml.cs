﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawMaxandMin(a.Text, b.Text);
        }

        public void DrawMaxandMin(string ax, string bx)
        {
            int a = Convert.ToInt32(ax);
            int b = Convert.ToInt32(bx);

            int minVal = a > b ? b : a;
            int maxval = a < b ? b : a;

            //plot min
            int minMark = 180;
            Line lm = new Line();
            lm.Stroke = Brushes.Red;
            lm.StrokeThickness = 2;
            lm.X1 = 100;
            lm.Y1 = minMark;
            lm.X2 = 107;
            lm.Y2 = minMark;
            TextBlock tbm = new TextBlock();
            tbm.Text = minVal.ToString();
            tbm.Margin = new Thickness(100,180,0,0);
            tbm.Padding = new Thickness(3);
            MainGrid.Children.Add(tbm);
            MainGrid.Children.Add(lm);

            //plot max
            int maxMark = 20;
            Line lx = new Line();
            lx.Stroke = Brushes.Red;
            lx.StrokeThickness = 2;
            lx.X1 = 100;
            lx.Y1 = maxMark;
            lx.X2 = 107;
            lx.Y2 = maxMark;
            TextBlock tbmx = new TextBlock();
            tbmx.Text = maxval.ToString();
            tbmx.Margin = new Thickness(100, 20, 0, 0);
            tbmx.Padding = new Thickness(3);
            MainGrid.Children.Add(tbmx);
            MainGrid.Children.Add(lx);

            Line dl = new Line();
            dl.Stroke = Brushes.Green;
            dl.StrokeThickness = 1;
            dl.X1 = 100;
            dl.Y1 = minMark;
            dl.X2 = 300;
            dl.Y2 = maxMark;
            MainGrid.Children.Add(dl);

            Line midpt = new Line();
            midpt.Stroke = Brushes.Red;
            midpt.StrokeThickness = 2;
            midpt.X1 = 100;
            midpt.Y1 = 100;
            midpt.X2 = 107;
            midpt.Y2 = midpt.Y1;

            MainGrid.Children.Add(midpt);


            TextBlock tbb = new TextBlock();
            tbb.Text = Convert.ToInt32((a + b) / 2).ToString();
            tbb.Margin = new Thickness(100,100,0,0);
            tbb.Padding = new Thickness(3);
            MainGrid.Children.Add(tbb);

        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 200, X2 = 300, Y2 = 200 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 0, X2 = 100, Y2 = 200 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 300, Y1 = 0, X2 = 300, Y2 = 200 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);
        }

        private Line l;
        private Line l1;
        private Line l2;
        private Line l3;
        private Line l4;

        private void Draw(object sender, RoutedEventArgs e)
        {

        }

        //private void Draw(object sender, RoutedEventArgs e)
        //{
        //    if (l != null && l1 != null && l2!=null && l3!=null && l4!=null)
        //    {
        //        MainGrid.Children.Remove(l);
        //        MainGrid.Children.Remove(l1);
        //        MainGrid.Children.Remove(l2);
        //        MainGrid.Children.Remove(l3);
        //        MainGrid.Children.Remove(l4);
        //    }

        //    l = new Line();
        //    l1 = new Line();
        //    l2 = new Line();
        //    l3 = new Line();
        //    l4 = new Line();
        //    if(c.Text.Equals("")&& d.Text.Equals(""))
        //    {
        //        l.X1 = 100;
        //        l.Y2 = 100 - Convert.ToDouble(a.Text);
        //        l.X2 = 300;
        //        l.Y1 = 100 - Convert.ToDouble(b.Text);
        //        l.Stroke = Brushes.Blue;
        //        l.StrokeThickness = 1.5;
        //        l.ToolTip = "(" + b.Text + ", " + a.Text + ")";
        //        MainGrid.Children.Add(l);

                

        //    }
        //    else
        //    {
        //        l.X1 = 100;
        //        l.Y2= 100 - Convert.ToDouble(a.Text);
        //        l.X2 = 300;
        //        l.Y1 = 100 - Convert.ToDouble(b.Text);
        //        l.Stroke = Brushes.Blue;
        //        l.StrokeThickness = 1.5;
        //        l.ToolTip = "(" + b.Text + ", " + a.Text + "+)";
        //        MainGrid.Children.Add(l);

        //        l1.X1 = 100;
        //        l1.Y2 = 100 - (Convert.ToDouble(c.Text) + Convert.ToDouble(a.Text)); 
        //        l1.X2 = 300;
        //        l1.Y1 = 100 - (Convert.ToDouble(d.Text) + Convert.ToDouble(b.Text)); 
        //        l1.Stroke = Brushes.Red;
        //        l1.StrokeThickness = 1.5;
        //        l1.ToolTip = "(" + d.Text + ", " + c.Text + ")";
        //        MainGrid.Children.Add(l1);
        //    }

        //    l2.X1 = 100;
        //    l2.Y1 = 100 - Convert.ToDouble(f.Text);
        //    l2.X2 = 300;
        //    l2.Y2 = l2.Y1;
        //    l2.Stroke = Brushes.Red;
        //    l2.StrokeDashArray = new DoubleCollection() { 5 };
        //    l1.ToolTip = "(" + f.Text + ", " + f.Text + ")";
        //    MainGrid.Children.Add(l2);


        //    l3.X1 = 100;
        //    l3.Y1 = 100 - Convert.ToDouble(g.Text);
        //    l3.X2 = 300;
        //    l3.Y2 = l3.Y1;
        //    l3.Stroke = Brushes.Blue;
        //    l3.StrokeDashArray = new DoubleCollection() { 5 };
        //    l3.ToolTip = "(" + g.Text + ", " + g.Text + ")";
        //    MainGrid.Children.Add(l3);

        //    l4.X1 = 100;
        //    l4.Y1 = 100 - Convert.ToDouble(h.Text);
        //    l4.X2 = 300;
        //    l4.Y2 = l4.Y1;
        //    l4.Stroke = Brushes.Yellow;
        //    l4.StrokeThickness = 1.5;
        //    l4.ToolTip = "(" + h.Text + ", " + h.Text + ")";
        //    MainGrid.Children.Add(l4);

        //}
    }
}
    
